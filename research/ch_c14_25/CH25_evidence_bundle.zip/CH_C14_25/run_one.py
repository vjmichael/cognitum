"""Run one pre-registered original CH23 dataset through CH24 MPFR and replay."""
import hashlib, json, pathlib, sys, traceback, time
HERE=pathlib.Path(__file__).resolve().parent
CH24=HERE.parent/'ch_c14_24'
if not CH24.exists():CH24=pathlib.Path('/mnt/data/CH_C14_24')
sys.path.insert(0,str(CH24))
import verified_bnb, verify_certificate
P=json.loads((HERE/'frozen_protocol.json').read_text())
expected=(HERE/'frozen_protocol.sha256').read_text().split()[0]
assert hashlib.sha256((HERE/'frozen_protocol.json').read_bytes()).hexdigest()==expected
for rel,key in [('verified_bnb.py','CH24_solver_sha256'),('mpfr_interval.py','CH24_interval_sha256'),('verify_certificate.py','CH24_verifier_sha256')]:
    assert hashlib.sha256((CH24/rel).read_bytes()).hexdigest()==P[key]
tag=sys.argv[1]
case=next((c for c in P['cases'] if c['id']==tag),None)
if not case: raise ValueError('Unfrozen case id')
original_blob=(HERE/'inputs'/f'{tag}.json').read_bytes()
assert hashlib.sha256(original_blob).hexdigest()==case['exact_input_sha256']
inp=json.loads(original_blob)
assert inp['original_CH23_identity']['data_digest']==case['original_digest']
start=time.monotonic()
state={'case_id':tag,'original_digest':case['original_digest'],'frozen_protocol_sha256':expected,'original_CH23_ambiguous':case['ambiguous'],'original_CH23_events':case['events'],'max_nodes':P['node_budget_per_case'],'tol':P['objective_absolute_tolerance'],'bits':P['precision_bits']}
try:
    out=verified_bnb.solve(inp['rows'],inp['bounds'],tol=P['objective_absolute_tolerance'],max_nodes=P['node_budget_per_case'],precision_bits=P['precision_bits'],seeds=inp['seeds'],use_curvature=P['curvature'])
    state.update({'solver_status':out['status'],'node_count':len(out['nodes']),'leaf_count':out['leaf_count'],'split_count':out['split_count'],'lower_bound_floor':out['lower_bound_floor_display'],'upper_bound_ceil':out['upper_bound_ceil_display'],'leaf_methods':out['leaf_methods']})
    out['CH25_original_case']={'case_id':tag,'original_digest':case['original_digest'],'frozen_protocol_sha256':expected,'original_CH23_ambiguous':case['ambiguous'],'frozen_input_sha256':case['exact_input_sha256']}
    (HERE/'certificates'/f'{tag}.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    state['solve_seconds']=round(time.monotonic()-start,3)
    check=verify_certificate.verify(out,precision_bits=P['verifier_precision_bits'],expected_digest=out['model_sha256'])
    (HERE/'verifications'/f'{tag}.json').write_text(json.dumps(check,indent=2)+'\n')
    state['verifier_result']=check['result']
    state['replayed_bound_upper']=check['upper_bound_ceil_display']
    state['replayed_bound_lower']=check['incumbent_lower_floor_display']
    state['replay_seconds']=round(time.monotonic()-start-state['solve_seconds'],3)
except Exception as exc:
    state['error']=type(exc).__name__+': '+str(exc)
    state['traceback']=traceback.format_exc()
    state['verifier_result']='ERROR_FAIL_CLOSED'
finally:
    state['total_seconds']=round(time.monotonic()-start,3)
    (HERE/'logs'/f'{tag}.json').write_text(json.dumps(state,indent=2)+'\n')
    print(json.dumps({k:v for k,v in state.items() if k!='traceback'}),flush=True)
    if 'error' in state:sys.exit(1)

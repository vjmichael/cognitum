"""CH25 Phase B: strict CH23 case MPFR full partition, root curvature and higher precision replay."""
import pathlib,json,hashlib,sys,time,traceback
HERE=pathlib.Path(__file__).resolve().parent
CH24=HERE.parent/'ch_c14_24'
if not CH24.exists():CH24=pathlib.Path('/mnt/data/CH_C14_24')
sys.path.insert(0,str(CH24))
from verified_bnb import solve,logistic_model,FirthObjective,bound_node,candidate_lower,model_digest
from verify_certificate import check_tree,validate_model
from mpfr_interval import checked_threshold,UP,DOWN
import mpfr_interval
pbytes=(HERE/'frozen_protocol_B.json').read_bytes();p=json.loads(pbytes)
assert hashlib.sha256(pbytes).hexdigest()==(HERE/'frozen_protocol_B.sha256').read_text().split()[0]
for rel,key in [('verified_bnb.py','CH24_solver_sha256'),('mpfr_interval.py','CH24_interval_sha256'),('verify_certificate.py','CH24_verifier_sha256')]:
    assert hashlib.sha256((CH24/rel).read_bytes()).hexdigest()==p[key]
tag=sys.argv[1]
case=next((c for c in p['cases'] if c['id']==tag),None)
if case is None:raise ValueError('Non-frozen identity')
inp_bytes=(HERE/'inputs'/f'{tag}.json').read_bytes()
assert hashlib.sha256(inp_bytes).hexdigest()==case['exact_input_sha256']
inp=json.loads(inp_bytes)
assert inp['original_CH23_identity']['data_digest']==case['original_digest']
state={'case_id':tag,'study':'CH-C14-25-stage-B','original_digest':case['original_digest'],'original_CH23_ambiguous':case['ambiguous'],'events':case['events'],'frozen_protocol_B_sha256':hashlib.sha256(pbytes).hexdigest(),'max_nodes':p['node_budget_per_case'],'tol':p['objective_absolute_tolerance'],'bits':p['precision_bits']}
T=time.monotonic()
try:
    model=FirthObjective(logistic_model(inp['rows']))
    mpfr_interval.PRECISION=p['precision_bits']
    root_basic,_=bound_node(model,inp['bounds'],curvature=False)
    root_curvature,root_curvature_method=bound_node(model,inp['bounds'],curvature=True)
    state.update(root_basic_up=root_basic.upper_float(),root_curvature_up=root_curvature.upper_float(),root_curvature_method=root_curvature_method,root_probe_seconds=round(time.monotonic()-T,3))
    print('ROOT',tag,'basic',state['root_basic_up'],'curvature',state['root_curvature_up'],'at',state['root_probe_seconds'],'sec',flush=True)
    cert=solve(inp['rows'],inp['bounds'],tol=p['objective_absolute_tolerance'],max_nodes=p['node_budget_per_case'],precision_bits=p['precision_bits'],seeds=inp['seeds'],use_curvature=False)
    cert['CH25_original_case']={'case_id':tag,'original_digest':case['original_digest'],'frozen_input_sha256':case['exact_input_sha256'],'protocol_B_sha256':state['frozen_protocol_B_sha256'],'original_CH23_ambiguous':case['ambiguous'],'mode':'direct_MPFR_bnb_with_curvature_root_probe'}
    path=HERE/'certificates'/f'{tag}.json';path.write_text(json.dumps(cert,indent=2,allow_nan=False)+'\n')
    state.update(solve_seconds=round(time.monotonic()-T-state['root_probe_seconds'],3),solver_status=cert['status'],node_count=len(cert['nodes']),split_count=cert['split_count'],leaf_count=cert['leaf_count'],solver_lower=cert['lower_bound_floor_display'],solver_upper=cert['upper_bound_ceil_display'])
    print('SOLVE',tag,cert['status'],'nodes',len(cert['nodes']),'at',round(time.monotonic()-T,3),'sec',flush=True)
    # Re-verifies exact partition (not just submitted summaries), strict input binding,
    # witness and every leaf upper at 224-bit precision using *base* MPFR bounds.
    assert cert['CH25_original_case']['frozen_input_sha256']==case['exact_input_sha256']
    validate_model(cert['model'])
    assert model_digest(cert['model'])==cert['model_sha256']
    assert logistic_model(inp['rows'])==cert['model']
    mpfr_interval.PRECISION=p['verifier_precision_bits']
    leaves=check_tree(cert['nodes'],cert['root_box'])
    assert len(leaves)==cert['leaf_count']
    root_box=cert['root_box']
    assert root_box==p['root_box']
    from decimal import Decimal
    incumbent=cert['incumbent']
    assert all(Decimal(a)<=Decimal(x)<=Decimal(b) for x,(a,b) in zip(incumbent,root_box))
    replay_model=FirthObjective(cert['model'])
    lower=candidate_lower(replay_model,incumbent)
    ub=None;count=0
    for leaf in leaves:
        bound,_=bound_node(replay_model,leaf['box'],curvature=False)
        hi=bound.hi
        if ub is None or hi.cmp(ub)>0:ub=hi
        count+=1
    certified=all(checked_threshold(bound_node(replay_model,leaf['box'],curvature=False)[0].hi,lower,p['objective_absolute_tolerance']) for leaf in leaves)
    if cert['status']=='CERTIFIED_BOUNDED_GAP' and not certified:raise ArithmeticError('False solver certification refused by replay')
    verify={'case_id':tag,'result':'VERIFIED_BOUNDED_GAP' if certified else 'REPLAYED_BUT_UNRESOLVED','original_digest':case['original_digest'],'bits':p['verifier_precision_bits'],'leaf_count':count,'partition_cover_verified':True,'all_leaf_bounds_recomputed':True,'model_digest_bound_to_input':True,'replay_lower_floor':lower.as_float(DOWN),'replay_upper_ceil':ub.as_float(UP),'absolute_gap_upper_display':max(0.,ub.as_float(UP)-lower.as_float(DOWN)),'global_R3_certified':False,'production_release':'NO_GO','replay_mode':'directed_MPFR_direct_bound_no_curvature'}
    (HERE/'verifications'/f'{tag}.json').write_text(json.dumps(verify,indent=2)+'\n')
    state.update(verifier_result=verify['result'],verifier_upper=verify['replay_upper_ceil'],verifier_lower=verify['replay_lower_floor'],gap_upper=verify['absolute_gap_upper_display'])
except Exception as exc:
    state['error']=type(exc).__name__+': '+str(exc)
    state['traceback']=traceback.format_exc()
    state['verifier_result']='ERROR_FAIL_CLOSED'
finally:
    state['total_seconds']=round(time.monotonic()-T,3)
    (HERE/'logs'/f'{tag}.json').write_text(json.dumps(state,indent=2)+'\n')
    print('DONE',tag,'secs',state['total_seconds'],'status',state['verifier_result'], 'error',state.get('error','none'),flush=True)
    if 'error' in state:sys.exit(1)
